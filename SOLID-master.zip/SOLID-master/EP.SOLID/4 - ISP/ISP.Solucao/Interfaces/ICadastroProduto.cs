namespace EP.SOLID.ISP.Solucao.Interfaces
{
    public interface ICadastroProduto
    {
        void ValidarDados();
        void SalvarBanco();
    }
}