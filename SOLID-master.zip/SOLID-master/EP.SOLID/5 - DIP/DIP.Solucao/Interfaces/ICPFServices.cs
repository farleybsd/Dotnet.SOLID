namespace EP.SOLID.DIP.Solucao.Interfaces
{
    public interface ICPFServices
    {
        bool IsValid(string cpf);
    }
}